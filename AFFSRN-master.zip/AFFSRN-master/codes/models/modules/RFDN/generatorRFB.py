import torch
import torch.nn as nn
import block as B
import RCAB

def make_model(args, parent=False):
    model = RFDN()
    return model


def default_conv(in_channels, out_channels, kernel_size, bias=True):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size//2), bias=bias)



## Residual Group (RG)
class ResidualGroup(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, act, res_scale, n_resblocks):
        super(ResidualGroup, self).__init__()
        modules_body = []
        modules_body = [
            RCAB.RCAB(
                default_conv,  n_feat, 3, bias=True, bn=False, act=nn.ReLU(True), res_scale=1) \
            for _ in range(4)]
        modules_body.append(conv(n_feat, n_feat, kernel_size))
        self.body = nn.Sequential(*modules_body)

    def forward(self, x):
        res = self.body(x)
        res += x
        return res


class RFDN(nn.Module):
    def __init__(self, in_nc=3, nf=64, num_modules=4, out_nc=3, upscale=4):   #50
        super(RFDN, self).__init__()
        act = nn.ReLU(True)
        self.fea_conv = B.conv_layer(in_nc, nf, kernel_size=3)

        self.B1 = B.RFDB(in_channels=nf)
        self.B2 = B.RFDB(in_channels=nf)
        self.B3 = B.RFDB(in_channels=nf)
        self.B4 = B.RFDB(in_channels=nf)
        self.c = B.conv_block(nf * num_modules, nf, kernel_size=1, act_type='lrelu')
        self.LR_conv = B.conv_layer(nf, nf, kernel_size=3)
        upsample_block = B.pixelshuffle_block
        self.upsampler = upsample_block(nf, out_nc, upscale_factor=4)
        self.scale_idx = 0

        # define body module
        modules_body = [
            ResidualGroup(
                default_conv, nf, 3, act=act, res_scale=1, n_resblocks=20) \
            for _ in range(10)]

        modules_body.append(default_conv(nf, nf, 3))
        self.body = nn.Sequential(*modules_body)

    def forward(self, input):
        out_fea = self.fea_conv(input)


        out_B1 = self.B1(out_fea)
        out_B2 = self.B2(out_B1)
        out_B3 = self.B3(out_B2)
        out_B4 = self.B4(out_B3)
        out_B = self.c(torch.cat([out_B1, out_B2, out_B3, out_B4], dim=1))

        res = self.body(out_fea)
        res += out_fea

        out_lr = self.LR_conv(out_B) + out_fea+res

        output = self.upsampler(out_lr)

        return output

    def set_scale(self, scale_idx):
        self.scale_idx = scale_idx


