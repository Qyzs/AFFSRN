import torch
import torch.nn as nn

import torch.nn.functional as F

from models.modules.RFDN import  common as c

#from wavelet import DWT_Haar, IWT_Haar
import os,cv2
import torchvision
loader = torchvision.transforms.Compose([torchvision.transforms.ToTensor()])
unloader = torchvision.transforms.ToPILImage()


def default_conv(in_channels, out_channels, kernel_size, bias=True):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size//2), bias=bias)
def stdv_channels(F):
    assert(F.dim() == 4)
    F_mean = mean_channels(F)
    F_variance = (F - F_mean).pow(2).sum(3, keepdim=True).sum(2, keepdim=True) / (F.size(2) * F.size(3))
    return F_variance.pow(0.5)

def sequential(*args):
    if len(args) == 1:
        if isinstance(args[0], OrderedDict):
            raise NotImplementedError('sequential does not support OrderedDict input.')
        return args[0]
    modules = []
    for module in args:
        if isinstance(module, nn.Sequential):
            for submodule in module.children():
                modules.append(submodule)
        elif isinstance(module, nn.Module):
            modules.append(module)
    return nn.Sequential(*modules)


def conv_layer(in_channels, out_channels, kernel_size, stride=1, dilation=1, groups=1):
    padding = int((kernel_size - 1) / 2) * dilation
    return nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding=padding, bias=True, dilation=dilation,
                     groups=groups)


def activation(act_type, inplace=True, neg_slope=0.05, n_prelu=1):
    act_type = act_type.lower()
    if act_type == 'relu':
        layer = nn.ReLU(inplace)
    elif act_type == 'gelu':
    		layer = nn.GELU()
    elif act_type == 'lrelu':
        layer = nn.LeakyReLU(neg_slope, inplace)
    elif act_type == 'prelu':
        layer = nn.PReLU(num_parameters=n_prelu, init=neg_slope)
    else:
        raise NotImplementedError('activation layer [{:s}] is not found'.format(act_type))
    return layer


def norm(norm_type, nc):
    norm_type = norm_type.lower()
    if norm_type == 'batch':
        layer = nn.BatchNorm2d(nc, affine=True)
    elif norm_type == 'instance':
        layer = nn.InstanceNorm2d(nc, affine=False)
    else:
        raise NotImplementedError('normalization layer [{:s}] is not found'.format(norm_type))
    return layer


def pad(pad_type, padding):
    pad_type = pad_type.lower()
    if padding == 0:
        return None
    if pad_type == 'reflect':
        layer = nn.ReflectionPad2d(padding)
    elif pad_type == 'replicate':
        layer = nn.ReplicationPad2d(padding)
    else:
        raise NotImplementedError('padding layer [{:s}] is not implemented'.format(pad_type))
    return layer


def get_valid_padding(kernel_size, dilation):
    kernel_size = kernel_size + (kernel_size - 1) * (dilation - 1)
    padding = (kernel_size - 1) // 2
    return padding



def conv_block(in_nc, out_nc, kernel_size, stride=1, dilation=1, groups=1, bias=True,
               pad_type='zero', norm_type=None, act_type='relu'):
    padding = get_valid_padding(kernel_size, dilation)
    p = pad(pad_type, padding) if pad_type and pad_type != 'zero' else None
    padding = padding if pad_type == 'zero' else 0

    c = nn.Conv2d(in_nc, out_nc, kernel_size=kernel_size, stride=stride, padding=padding,
                  dilation=dilation, bias=bias, groups=groups)
    a = activation(act_type) if act_type else None
    n = norm(norm_type, out_nc) if norm_type else None
    return sequential(p, c, n, a)

def default_conv(in_channels, out_channels, kernel_size, bias=True):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size//2), bias=bias)

class Get_gradient_nopadding(nn.Module):
    def __init__(self):
        super(Get_gradient_nopadding, self).__init__()
        kernel_v = [[0, -1, 0],
                    [0, 0, 0],
                    [0, 1, 0]]
        kernel_h = [[0, 0, 0],
                    [-1, 0, 1],
                    [0, 0, 0]]
        kernel_h = torch.FloatTensor(kernel_h).unsqueeze(0).unsqueeze(0)
        kernel_v = torch.FloatTensor(kernel_v).unsqueeze(0).unsqueeze(0)
        self.weight_h = nn.Parameter(data=kernel_h, requires_grad=False)

        self.weight_v = nn.Parameter(data=kernel_v, requires_grad=False)

    def forward(self, x):
        x_list = []
        for i in range(x.shape[1]):
            x_i = x[:, i]
            x_i_v = F.conv2d(x_i.unsqueeze(1), self.weight_v, padding=1)
            x_i_h = F.conv2d(x_i.unsqueeze(1), self.weight_h, padding=1)
            x_i = torch.sqrt(torch.pow(x_i_v, 2) + torch.pow(x_i_h, 2) + 1e-6)
            x_list.append(x_i)

        x = torch.cat(x_list, dim=1)

        return x

def make_model(args, parent=False):
    model = RFDN()
    return model


def default_conv(in_channels, out_channels, kernel_size, bias=True):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size//2), bias=bias)


class Scale(nn.Module):

    def __init__(self, init_value=1e-3):
        super().__init__()
        self.scale = nn.Parameter(torch.FloatTensor([init_value]))

    def forward(self, input):
        return input * self.scale

class Tail(nn.Module):
    def __init__(
        self,  scale, n_feats, kernel_size, wn):
        super(Tail, self).__init__()
        out_feats = scale*scale*3
        self.tail_k3 = wn(nn.Conv2d(n_feats, out_feats, 3, padding=3//2, dilation=1,groups=6))
        self.tail_k5 = wn(nn.Conv2d(n_feats, out_feats, 5, padding=5//2, dilation=1,groups=6))

        self.pixelshuffle = nn.PixelShuffle(scale)
        self.scale_k3 = Scale(0.5)
        self.scale_k5 = Scale(0.5)

        self.conv = wn(nn.Conv2d(n_feats, 3, 3,padding=3//2, dilation=1))


    def forward(self, x):

        x0 = self.pixelshuffle( self.scale_k3(self.tail_k3(x)))

        x1 = self.pixelshuffle(self.scale_k5(self.tail_k5(x)))


        out = torch.nn.functional.upsample(self.conv(x), scale_factor=4, mode='bicubic')
        return x0+x1+out


# class Tail(nn.Module):
#     def __init__(
#         self,  scale, n_feats, kernel_size, wn):
#         super(Tail, self).__init__()
#         out_feats = scale*scale*3
#         self.tail_k3 = wn(nn.Conv2d(n_feats, out_feats//2, 3, padding=3//2, dilation=1))
#         self.tail_k5 = wn(nn.Conv2d(n_feats, out_feats//2, 5, padding=5//2, dilation=1))
#
#         self.pixelshuffle = nn.PixelShuffle(scale)
#         self.scale_k3 = Scale(0.5)
#         self.scale_k5 = Scale(0.5)
#
#         self.conv = wn(nn.Conv2d(n_feats, 3, 3, padding=3 // 2, dilation=1))
#
#
#     def forward(self, x):
#
#         x0 = self.pixelshuffle( torch.cat([self.scale_k3(self.tail_k3(x)),self.tail_k5(x) ], 1))
#
#         x1 = self.pixelshuffle(torch.cat([self.tail_k3(x),self.scale_k5(self.tail_k5(x)) ], 1))
#
#
#         out = torch.nn.functional.upsample(self.conv(x), scale_factor=4, mode='bicubic')
#         return x0+x1+out

def pixel_unshuffle(input, downscale_factor):
    '''
    input: batchSize * c * k*w * k*h
    kdownscale_factor: k
    batchSize * c * k*w * k*h -> batchSize * k*k*c * w * h
    '''
    c = input.shape[1]

    kernel = torch.zeros(size=[downscale_factor * downscale_factor * c,
                               1, downscale_factor, downscale_factor],
                         device=input.device)
    for y in range(downscale_factor):
        for x in range(downscale_factor):
            kernel[x + y * downscale_factor::downscale_factor*downscale_factor, 0, y, x] = 1
    return F.conv2d(input, kernel, stride=downscale_factor, groups=c)


def conv(in_planes, out_planes, kernel_size=3, stride=1, padding=1, dilation=1, groups=1):
    """standard convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                     padding=padding, dilation=dilation, groups=groups, bias=False)


class UpsampleOneStep(nn.Sequential):
    """UpsampleOneStep module (the difference with Upsample is that it always only has 1conv + 1pixelshuffle)
       Used in lightweight SR to save parameters.

    Args:
        scale (int): Scale factor. Supported scales: 2^n and 3.
        num_feat (int): Channel number of intermediate features.

    """

    def __init__(self, scale, num_feat, num_out_ch, input_resolution=None):
        self.num_feat = num_feat
        self.input_resolution = input_resolution
        m = []
        m.append(nn.Conv2d(num_feat, (scale ** 2) * num_out_ch, 3, 1, 1))
        m.append(nn.PixelShuffle(scale))
        super(UpsampleOneStep, self).__init__(*m)

    def flops(self):
        H, W = self.input_resolution
        flops = H * W * self.num_feat * 3 * 9
        return flops



#  Grad
class RFDN(nn.Module):
    def __init__(self, in_nc=3, nf=90, num_modules=4, out_nc=3, upscale=4, nb=20):  # 50
        super(RFDN, self).__init__()

        self.fea_conv = conv_layer(in_nc, nf, kernel_size=3)
        self.fea_conv_grad = conv_layer(in_nc, nf, kernel_size=3)
        self.get_g_nopadding = Get_gradient_nopadding()

        self.scale = upscale
        wn = lambda x: torch.nn.utils.weight_norm(x)
        self.act = nn.LeakyReLU(True)

        #
        self.B1 = c.ResSwinBlock(nf)
        self.B2 = c.ResSwinBlock(nf)
        self.B3 = c.ResSwinBlock(nf)
        self.B4 = c.ResSwinBlock(nf)
        # self.B5 = c.ResSwinBlock(nf,k=4)

        #
        self.c1 = conv_block(nf * 2, nf, kernel_size=1, act_type='gelu')
        self.c = conv_block(nf * num_modules, nf, kernel_size=1, act_type='gelu')
        self.LR_conv =  BSConvU(nf,nf)

        self.tail = Tail(self.scale, nf, 3, wn)

    def forward(self, input):
        out_fea = self.fea_conv(input)

        x_grad = self.get_g_nopadding(input)
        out_fea_grad = self.fea_conv_grad(x_grad)
        out_B1 = self.B1(out_fea)
        out_B2 = self.B2(out_B1)
        out_B3 = self.B3(out_B2)


        input_grad = self.c1(torch.cat((out_B2, out_fea_grad), dim=1))
        out_B4 = self.B4(input_grad) + out_fea_grad
        # out_B5 = self.B5(out_B4)

        out = self.c(torch.cat((out_B1,out_B2,out_B3,out_B4), dim=1))
        out = self.LR_conv(out)

        out = self.tail(out)

        r = torch.nn.functional.upsample(input, scale_factor=4, mode='bicubic')
        output = out + r

        return output

    def set_scale(self, scale_idx):
        self.scale_idx = scale_idx

class BSConvU(torch.nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1,
                 dilation=1, bias=True, padding_mode="zeros", with_ln=False, bn_kwargs=None):
        super().__init__()
        self.with_ln = with_ln
        # check arguments
        if bn_kwargs is None:
            bn_kwargs = {}

        # pointwise
        self.pw = nn.Linear(in_channels, out_channels)


        # depthwise
        self.dw = torch.nn.Conv2d(
                in_channels=out_channels,
                out_channels=out_channels,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                groups=out_channels,
                bias=bias,
                padding_mode=padding_mode,
        )

    def forward(self, fea):
        fea = fea.permute(0, 2, 3, 1)
        fea = self.pw(fea)
        fea = self.dw(fea.permute(0, 3, 1, 2))
        return fea

# class RFDN(nn.Module):
#     def __init__(self, in_nc=3, nf=90, num_modules=2, out_nc=3, upscale=4, nb=20):  # 50
#         super(RFDN, self).__init__()
#
#         self.fea_conv = B.conv_layer(in_nc, nf, kernel_size=3)
#         self.fea_conv_grad = B.conv_layer(in_nc, nf, kernel_size=3)
#         self.get_g_nopadding = Get_gradient_nopadding()
#
#         self.scale = upscale
#         wn = lambda x: torch.nn.utils.weight_norm(x)
#         self.act = nn.LeakyReLU(True)
#
#         #
#         self.B1 = c.ResSwinBlock(nf)
#         #        self.B2 = c.ResSwinBlock(nf)
#         #        self.B3 = c.ResSwinBlock(nf)
#         self.B4 = c.ResSwinBlock(nf)
#
#         #
#         self.c1 = B.conv_block(nf * 2, nf, kernel_size=1, act_type='lrelu')
#         self.c = B.conv_block(nf * num_modules, nf, kernel_size=1, act_type='lrelu')
#         self.LR_conv = B.conv_layer(nf, nf, kernel_size=3)
#
#         self.tail = Tail(self.scale, nf, 3, wn)
#
#     def forward(self, input):
#         out_fea = self.fea_conv(input)
#
#         x_grad = self.get_g_nopadding(input)
#         out_fea_grad = self.fea_conv_grad(x_grad)
#         out_B1 = self.B1(out_fea)
#         #        out_B2 = self.B2( out_B1 )
#         #        out_B3 = self.B3( out_B2)
#
#         input_grad = self.c1(torch.cat((out_B1, out_fea_grad), dim=1))
#         out_B4 = self.B4(input_grad) + out_fea_grad
#         out = self.LR_conv(self.c(torch.cat((out_B1, out_B4), dim=1)))
#         out = self.tail(out)
#
#         r = torch.nn.functional.upsample(input, scale_factor=4, mode='bicubic')
#         output = out + r
#
#         return output
#
#     def set_scale(self, scale_idx):
#         self.scale_idx = scale_idx
