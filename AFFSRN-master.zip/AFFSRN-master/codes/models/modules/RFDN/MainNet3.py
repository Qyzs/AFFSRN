import torch
import torch.nn as nn
import torch.nn.functional as F
from coordatt import CoordAtt
from ESA import ESA
from RFDN import block as B
from TTSR__RRDBNet_arch import RRDB
import functools
import models.modules.module_util as mutil
#import prue
class QuantConv2d(nn.Conv2d):
        def __init__(self, in_channels, out_channels, kernel_size, stride=1,padding=0, dilation=1, groups=1, bias=True):
            super(QuantConv2d, self).__init__(in_channels, out_channels, kernel_size, stride, padding, dilation, groups, bias)

            self.quant_flag = False
            self.scale = None
            self.zero_point = None

        def linear_quant(self, quantize_bit=8):
            self.weight.data, self.scale, self.zero_point = quantize_tensor(self.weight.data, num_bits=quantize_bit)
            self.quant_flag = True

        def forward(self, x):
            if self.quant_flag == True:
               weight = dequantize_tensor(self.weight, self.scale, self.zero_point)
               return F.conv2d(x, weight, self.bias, self.stride,self.padding, self.dilation, self.groups)
            else:
               return F.conv2d(x, self.weight, self.bias, self.stride,self.padding, self.dilation, self.groups)

def quantize_tensor(x, num_bits=8):
    qmin = 0.
    qmax = 2.**num_bits - 1.
    min_val, max_val = x.min(), x.max()

    scale = (max_val - min_val) / (qmax - qmin)

    initial_zero_point = qmin - min_val / scale

    zero_point = 0

    if initial_zero_point < qmin:
      zero_point = qmin

    elif initial_zero_point > qmax:
      zero_point = qmax

    else:
      zero_point = initial_zero_point

    zero_point = int(zero_point)
    q_x = zero_point + x / scale
    q_x.clamp_(qmin, qmax).round_()
    q_x = q_x.round().byte()
    return q_x, scale, zero_point






def dequantize_tensor(q_x, scale, zero_point):

    return scale * (q_x.float() - zero_point)



def conv1x1(in_channels, out_channels, stride=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size=1,
                     stride=stride, padding=0, bias=True)


def conv3x3(in_channels, out_channels, stride=1):

    #return prue.MaskedConv2d(in_channels, out_channels, kernel_size=3, padding=1, stride=1)
    return nn.Conv2d(in_channels, out_channels, kernel_size=3,stride=stride, padding=1, bias=True)
    #return   QuantConv2d(in_channels, out_channels, kernel_size=3, padding=1, stride=1)


def get_valid_padding(kernel_size, dilation):
    kernel_size = kernel_size + (kernel_size - 1) * (dilation - 1)
    padding = (kernel_size - 1) // 2
    return padding

def pad(pad_type, padding):
    pad_type = pad_type.lower()
    if padding == 0:
        return None
    if pad_type == 'reflect':
        layer = nn.ReflectionPad2d(padding)
    elif pad_type == 'replicate':
        layer = nn.ReplicationPad2d(padding)
    else:
        raise NotImplementedError('padding layer [%s] is not implemented' % pad_type)
    return layer

def sequential(*args):
    if len(args) == 1:
        if isinstance(args[0], OrderedDict):
            raise NotImplementedError('sequential does not support OrderedDict input.')
        return args[0]
    modules = []
    for module in args:
        if isinstance(module, nn.Sequential):
            for submodule in module.children():
                modules.append(submodule)
        elif isinstance(module, nn.Module):
            modules.append(module)
    return nn.Sequential(*modules)

def activation(act_type, inplace=True, neg_slope=0.05, n_prelu=1):
    act_type = act_type.lower()
    if act_type == 'relu':
        layer = nn.ReLU(inplace)
    elif act_type == 'lrelu':
        layer = nn.LeakyReLU(neg_slope, inplace)
    elif act_type == 'prelu':
        layer = nn.PReLU(num_parameters=n_prelu, init=neg_slope)
    else:
        raise NotImplementedError('activation layer [{:s}] is not found'.format(act_type))
    return layer

def conv_block(in_nc, out_nc, kernel_size, stride=1, dilation=1, groups=1, bias=True,
               pad_type='zero', norm_type=None, act_type='relu'):
    padding = get_valid_padding(kernel_size, dilation)
    p = pad(pad_type, padding) if pad_type and pad_type != 'zero' else None
    padding = padding if pad_type == 'zero' else 0

    c = nn.Conv2d(in_nc, out_nc, kernel_size=kernel_size, stride=stride, padding=padding,
                  dilation=dilation, bias=bias, groups=groups)
    a = activation(act_type) if act_type else None
    n = norm(norm_type, out_nc) if norm_type else None
    return sequential(p, c, n, a)

class MAB(nn.Module):
    def __init__(self, n_feats, reduction_factor=4, distillation_rate=0.25):
        super(MAB, self).__init__()
        self.reduce_channels = nn.Conv2d(n_feats, n_feats//reduction_factor,1)
        self.reduce_spatial_size = nn.Conv2d(n_feats//reduction_factor, n_feats//reduction_factor, 3, stride=2, padding=1)
        self.pool = nn.MaxPool2d(7, stride=3)
        self.increase_channels = conv_block(n_feats//reduction_factor, n_feats, 1)

        self.conv1 = conv_block(n_feats//reduction_factor, n_feats//reduction_factor,3,dilation=1,act_type='lrelu')
        self.conv2 = conv_block(n_feats // reduction_factor, n_feats//reduction_factor, 3,dilation=2,act_type='lrelu')

        self.sigmoid = nn.Sigmoid()

        self.conv00 = conv_block(n_feats, n_feats,3, act_type=None)
        self.conv01 = conv_block(n_feats, n_feats,3,act_type='lrelu')

        self.bottom11 = conv_block(n_feats,n_feats,1,act_type=None)
        self.bottom11_dw = conv_block(n_feats, n_feats,5, groups=n_feats,act_type=None)

    def forward(self, x):
        x  = self.conv00(self.conv01(x))
        rc = self.reduce_channels(x)
        rs = self.reduce_spatial_size(rc)
        pool = self.pool(rs)
        conv = self.conv2(pool)
        conv = conv + self.conv1(pool)
        up =  torch.nn.functional.upsample(conv, size=(rc.shape[2],rc.shape[3]), mode='nearest')
        up =  up + rc
        out = (self.sigmoid(self.increase_channels(up)) * x) *  self.sigmoid(self.bottom11_dw(self.bottom11(x)))
        return out

class Att(nn.Module):
    def __init__(self, n_feats):
        super(Att,self).__init__()
        self.ca=CoordAtt(n_feats,n_feats)
        self.esa=ESA(n_feats)
        # self.conv1 = conv1x1(n_feats, n_feats)


    def forward(self,x):
        # out=self.ca(x)
        out=self.esa(x,x)     #？有作用么？
        # out=self.conv1(out)
        return out


class ResBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, downsample=None, res_scale=1):
        super(ResBlock, self).__init__()
        self.res_scale = res_scale
        self.conv1 = conv3x3(in_channels, out_channels, stride)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(out_channels, out_channels)
        # self.MAB = MAB(64,4)
        self.RFB = ReceptiveFieldBlock(64, 64, non_linearity=False)
        # self.esa = ESA(out_channels)
        self.ca = Att(out_channels)

    def forward(self, x):
        x1 = x
        out = self.conv1(x)
        out = self.relu(out)
        out = self.conv2(out)
        # out = self.relu(out)
        # out = self.MAB(out)
        # out = self.relu(out)
        out = self.RFB(out)
        out = self.relu(out)
        out = self.ca(out)
        out = out * self.res_scale + x1
        return out

class ReceptiveFieldBlock(nn.Module):
    r"""This structure is similar to the main building blocks in the GoogLeNet model.
    `"Going Deeper with Convolutions" <http://arxiv.org/abs/1409.4842>`_.
    """

    def __init__(self, in_channels, out_channels, scale_ratio=0.2, non_linearity=True):
        super(ReceptiveFieldBlock, self).__init__()
        channels = in_channels // 4
        # shortcut layer
        self.shortcut = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0)

        self.branch1 = nn.Sequential(
            nn.Conv2d(in_channels, channels, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=1, dilation=1)
        )

        self.branch2 = nn.Sequential(
            nn.Conv2d(in_channels, channels, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=(1, 3), stride=1, padding=(0, 1)),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=3, dilation=3)
        )

        self.branch3 = nn.Sequential(
            nn.Conv2d(in_channels, channels, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=(3, 1), stride=1, padding=(1, 0)),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=3, dilation=3)
        )

        self.branch4 = nn.Sequential(
            nn.Conv2d(in_channels, channels // 2, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels // 2, (channels // 4) * 3, kernel_size=(1, 3), stride=1, padding=(0, 1)),
            nn.ReLU(inplace=True),
            nn.Conv2d((channels // 4) * 3, channels, kernel_size=(1, 3), stride=1, padding=(0, 1)),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, stride=1, padding=5, dilation=5)
        )

        self.conv1x1 = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True) if non_linearity else None

        self.scale_ratio = scale_ratio

        for m in self.modules():      #权值初始化
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight)
                m.weight.data *= 0.1
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                nn.init.kaiming_normal_(m.weight)
                m.weight.data *= 0.1
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias.data, 0.0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        shortcut = self.shortcut(x)

        branch1 = self.branch1(x)
        branch2 = self.branch2(x)
        branch3 = self.branch3(x)
        branch4 = self.branch4(x)

        out = torch.cat((branch1, branch2, branch3, branch4), dim=1)
        out = self.conv1x1(out)

        out = out.mul(self.scale_ratio) + shortcut
        if self.lrelu is not None:
            out = self.lrelu(out)

        return out



class SFE(nn.Module):
    def __init__(self, num_res_blocks, n_feats, nDenselayer=5,growthRate=32):
        super(SFE, self).__init__()
        self.num_res_blocks = num_res_blocks
        self.conv_head = conv3x3(3, n_feats)
        
        self.RBs = nn.ModuleList()
        for i in range(self.num_res_blocks):
            self.RBs.append(ResBlock(in_channels=n_feats, out_channels=n_feats,
                                     res_scale=1))

        self.conv_tail = conv3x3(n_feats, n_feats)
        
    def forward(self, x):
        x_ori = self.conv_head(x)
        x = F.relu(self.conv_head(x))
        x1 = x
        for i in range(self.num_res_blocks):
            x = self.RBs[i](x)
        x = self.conv_tail(x)
        x = x + x1
        return x_ori,x

class RB(nn.Module):
    def __init__(self,nf=64):
        super(RB,self).__init__()
        self.B1 = ResBlock(nf, nf, res_scale=1)
        self.B2 = ResBlock(nf, nf, res_scale=1)
        self.B3 = ResBlock(nf, nf, res_scale=1)
        self.B4 = ResBlock(nf, nf, res_scale=1)
        self.c = conv1x1(nf * 4, nf)

    def forward(self, x ):
        out_B1 = self.B1(x)
        out_B2 = self.B2(out_B1)
        out_B3 = self.B3(out_B2)
        out_B4 = self.B4(out_B3)

        out_B = self.c(torch.cat([out_B1, out_B2, out_B3, out_B4], dim=1))
        return out_B



class MainNet(nn.Module):
    def __init__(self,opt):
        super(MainNet, self).__init__()
        if opt['dist']:
            self.rank = torch.distributed.get_rank()
        else:
            self.rank = -1  # non dist training
        network_opt = opt['network']
        self.num_res_blocks = list(map(int, network_opt['num_res_blocks'].split('+')))
         ### a list containing number of resblocks of different stages
        self.n_feats =network_opt['n_feats']
        self.fea_conv = conv3x3(3, network_opt['n_feats'])

        body = []
        for i in range(3):    #16
            body.append(
                RB()
            )


        self.LR_conv = B.conv_layer(network_opt['n_feats'],network_opt['n_feats'], kernel_size=3)

        upsample_block = B.pixelshuffle_block
        self.upsampler = upsample_block(network_opt['n_feats'], 3, upscale_factor=4)

        self.body = nn.Sequential(*body)


    def forward(self, x):

        out_fea = self.fea_conv(x)

        out =self.body(out_fea)
        out_lr = self.LR_conv(out) + out_fea

        output = self.upsampler(out_lr)


        return output

