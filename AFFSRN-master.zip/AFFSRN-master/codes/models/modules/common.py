import math
import numpy as np
import torch
import torch.nn as nn
from torch.nn import functional as F
from .blocks import ConvBlock, DeconvBlock, MeanShift
import models.modules.module_util as mutil
import functools

def default_conv(in_channels, out_channels, kernel_size, bias=True):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size,
        padding=(kernel_size // 2), bias=bias)


class MeanShift(nn.Conv2d):
    def __init__(self, rgb_range, rgb_mean, rgb_std, sign=-1):
        super(MeanShift, self).__init__(3, 3, kernel_size=1)
        std = torch.Tensor(rgb_std)
        self.weight.data = torch.eye(3).view(3, 3, 1, 1)
        self.weight.data.div_(std.view(3, 1, 1, 1))
        self.bias.data = sign * rgb_range * torch.Tensor(rgb_mean)
        self.bias.data.div_(std)
        self.requires_grad = False

class PA(nn.Module):
    '''PA is pixel attention'''
    def __init__(self, nf):

        super(PA, self).__init__()
        self.conv = nn.Conv2d(nf, nf, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):

        y = self.conv(x)
        y = self.sigmoid(y)
        out = torch.mul(x, y)

        return out

class Upsampler2(nn.Sequential):
    def __init__(self, conv, scale, n_feats, bn=False, act=False, bias=True):
        m = []

        if (scale & (scale - 1)) == 0:  # Is scale = 2^n?
            for _ in range(int(math.log(scale, 2))):
                m.append(conv(n_feats, 24, 3, bias))
                m.append(PA(24))
                m.append(conv(24, n_feats, 3, bias))
                if bn: m.append(nn.BatchNorm2d(n_feats))

                if act == 'relu':
                    m.append(nn.ReLU(True))
                elif act == 'prelu':
                    m.append(nn.PReLU(n_feats))

        elif scale == 3:
            m.append(conv(n_feats, 9 * n_feats, 3, bias))
            m.append(nn.PixelShuffle(3))
            if bn: m.append(nn.BatchNorm2d(n_feats))

            if act == 'relu':
                m.append(nn.ReLU(True))
            elif act == 'prelu':
                m.append(nn.PReLU(n_feats))
        else:
            raise NotImplementedError

        super(Upsampler, self).__init__(*m)


class Upsampler(nn.Module):
    def __init__(self, conv, scale, n_feats, bn=False, act=False, bias=True):
        super(Upsampler, self).__init__()
        n_feats = n_feats
        self.scale = scale
        #### upsampling
        self.upconv1 = nn.Conv2d(n_feats, 24, 3, 1, 1, bias=True)
        self.att1 = PA(24)
        self.HRconv1 = nn.Conv2d(24,n_feats, 3, 1, 1, bias=True)

        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

    def forward(self, x):


        if self.scale == 2 :
            fea = self.upconv1(F.interpolate(x, scale_factor=self.scale, mode='nearest'))
            fea = self.lrelu(self.att1(fea))
            fea = self.lrelu(self.HRconv1(fea))

        return fea
class DownBlock(nn.Module):
    def __init__(self, opt, scale, nFeat=None, in_channels=None, out_channels=None):
        super(DownBlock, self).__init__()
        negval =0.2

        if nFeat is None:
            nFeat = opt.n_feats

        if in_channels is None:
            in_channels = opt.n_colors

        if out_channels is None:
            out_channels = opt.n_colors

        dual_block = [
            nn.Sequential(
                nn.Conv2d(in_channels, nFeat, kernel_size=3, stride=2, padding=1, bias=False),
                nn.LeakyReLU(negative_slope=negval, inplace=True)
            )
        ]

        for _ in range(1, int(np.log2(scale))):
            dual_block.append(
                nn.Sequential(
                    nn.Conv2d(nFeat, nFeat, kernel_size=3, stride=2, padding=1, bias=False),
                    nn.LeakyReLU(negative_slope=negval, inplace=True)
                )
            )

        dual_block.append(nn.Conv2d(nFeat, out_channels, kernel_size=3, stride=1, padding=1, bias=False))

        self.dual_module = nn.Sequential(*dual_block)

    def forward(self, x):
        x = self.dual_module(x)
        return x

class DownBlock2(nn.Module):
    def __init__(self, opt, scale, nFeat=None, in_channels=None, out_channels=None):
        super(DownBlock2, self).__init__()
        negval =0.2

        if nFeat is None:
            nFeat = opt.n_feats

        if in_channels is None:
            in_channels = opt.n_colors

        if out_channels is None:
            out_channels = opt.n_colors



        self.conv1 = nn.Conv2d(in_channels , nFeat, kernel_size=3, stride=2, padding=1, bias=False)
        self.relu1 = nn.LeakyReLU(negative_slope=negval, inplace=True)

        # self.conv2 = nn.Conv2d(nFeat, nFeat, kernel_size=3, stride=2, padding=1, bias=False)
        # self.relu2 = nn.LeakyReLU(negative_slope=negval, inplace=True)

        self.conv3 = nn.Conv2d(nFeat, out_channels, kernel_size=3, stride=1, padding=1, bias=False)


    def forward(self, x):
        x = self.conv1(x)
        x = self.relu1(x)

        # x = self.conv2(x)
        # x = self.relu2(x)

        x = self.conv3(x)

        return x


## Channel Attention (CA) Layer
class CALayer(nn.Module):
    def __init__(self,channel, reduction=16):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y


## Residual Channel Attention Block (RCAB)
class RCAB(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction=16,
                 bias=True, bn=False, act=nn.ReLU(True), res_scale=1):
        super(RCAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)
        modules_body.append(CALayer(n_feat, reduction))
        self.body = nn.Sequential(*modules_body)
        self.res_scale = res_scale

    def forward(self, x):
        res = self.body(x)
        res += x
        return res


class SCPA(nn.Module):
    """SCPA is modified from SCNet (Jiang-Jiang Liu et al. Improving Convolutional Networks with Self-Calibrated Convolutions. In CVPR, 2020)
        Github: https://github.com/MCG-NKU/SCNet
    """

    def __init__(self,conv, nf, kernel_size, reduction=2, stride=1, dilation=1,act=nn.ReLU(True)):
        super(SCPA, self).__init__()
        group_width = nf // reduction

        self.conv1_a = nn.Conv2d(nf, group_width, kernel_size=1, bias=False)
        self.conv1_b = nn.Conv2d(nf, group_width, kernel_size=1, bias=False)

        self.k1 = nn.Sequential(
            nn.Conv2d(
                group_width, group_width, kernel_size=3, stride=stride,
                padding=dilation, dilation=dilation,
                bias=False)
        )

        self.PAConv = PAConv(group_width)

        self.conv3 = nn.Conv2d(
            group_width * reduction, nf, kernel_size=1, bias=False)

        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

    def forward(self, x):
        residual = x

        out_a = self.conv1_a(x)
        out_b = self.conv1_b(x)
        out_a = self.lrelu(out_a)
        out_b = self.lrelu(out_b)

        out_a = self.k1(out_a)
        out_b = self.PAConv(out_b)
        out_a = self.lrelu(out_a)
        out_b = self.lrelu(out_b)

        out = self.conv3(torch.cat([out_a, out_b], dim=1))
        out += residual

        return out


class PAConv(nn.Module):

    def __init__(self, nf, k_size=3):
        super(PAConv, self).__init__()
        self.k2 = nn.Conv2d(nf, nf, 1)  # 1x1 convolution nf->nf
        self.sigmoid = nn.Sigmoid()
        self.k3 = nn.Conv2d(nf, nf, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)  # 3x3 convolution
        self.k4 = nn.Conv2d(nf, nf, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)  # 3x3 convolution

    def forward(self, x):
        y = self.k2(x)
        y = self.sigmoid(y)

        out = torch.mul(self.k3(x), y)
        out = self.k4(out)

        return out


class ResidualDenseBlock_5C(nn.Module):
    def __init__(self, nf=64, gc=32, bias=True):
        super(ResidualDenseBlock_5C, self).__init__()
        # gc: growth channel, i.e. intermediate channels
        self.conv1 = nn.Conv2d(nf, gc, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(nf + gc, gc, 3, 1, 1, bias=bias)
        self.conv3 = nn.Conv2d(nf + 2 * gc, gc, 3, 1, 1, bias=bias)
        self.conv4 = nn.Conv2d(nf + 3 * gc, gc, 3, 1, 1, bias=bias)
        self.conv5 = nn.Conv2d(nf + 4 * gc, nf, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

        # initialization
        # mutil.initialize_weights([self.conv1, self.conv2, self.conv3, self.conv4, self.conv5], 0.1)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5 * 0.2 + x


class RRDB(nn.Module):
    '''Residual in Residual Dense Block'''

    def __init__(self, conv, nf, kernel_size, reduction=16,
                 bias=True, bn=False, act=nn.ReLU(True), res_scale=1, gc=32):
        super(RRDB, self).__init__()
        self.RDB1 = ResidualDenseBlock_5C(nf, gc)
        self.RDB2 = ResidualDenseBlock_5C(nf, gc)
        self.RDB3 = ResidualDenseBlock_5C(nf, gc)

    def forward(self, x):
        out = self.RDB1(x)
        out = self.RDB2(out)
        out = self.RDB3(out)
        return out * 0.2 + x


class _Residual_Block(nn.Module):
    def __init__(self, conv, n_feats, kernel_size, act=False):
        super(_Residual_Block, self).__init__()

        self.conv1 = nn.Conv2d(n_feats, n_feats, kernel_size=3, stride=1, padding=1, bias=False)
        self.in1 = nn.InstanceNorm2d(n_feats, affine=True)
        self.relu = nn.LeakyReLU(0.2, inplace=True)
        self.conv2 = nn.Conv2d(n_feats, n_feats, kernel_size=3, stride=1, padding=1, bias=False)
        self.in2 = nn.InstanceNorm2d(n_feats, affine=True)

        self.calyer = CALayer(conv, n_feats, reduction=16)

    def forward(self, x):
        identity_data = x
        output = self.relu(self.conv1(x))
        output = self.conv2(output)
        # output = torch.add(output,identity_data)
        output = self.calyer(output)
        return output


class ESAB(nn.Module):
    def __init__(self, conv, n_feat, kernel_size=3, reduction=16,
                 bias=True, bn=False, act=nn.ReLU(True), res_scale=1):
        super(ESAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)
        modules_body.append(CALayer(conv, n_feat, reduction))
        # modules_body.append(ESA(n_feat))
        self.body = nn.Sequential(*modules_body)
        self.res_scale = res_scale

    def forward(self, x):
        res = self.body(x)
        return res


def default_conv2(in_channels, out_channels, kernel_size, stride=1, padding=None, bias=True, groups=1):
    if not padding and stride == 1:
        padding = kernel_size // 2
    return nn.Conv2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, bias=bias, groups=groups)


class ESA(nn.Module):
    def __init__(self, n_feats, conv=default_conv2):
        super(ESA, self).__init__()
        f = n_feats // 4
        self.conv1 = conv(n_feats, f, kernel_size=1)
        self.conv_f = conv(f, f, kernel_size=1)
        self.conv_max = conv(f, f, kernel_size=3, padding=1)
        self.conv2 = conv(f, f, kernel_size=3, stride=2, padding=0)
        self.conv3 = conv(f, f, kernel_size=3, padding=1)
        self.conv3_ = conv(f, f, kernel_size=3, padding=1)
        self.conv4 = conv(f, n_feats, kernel_size=1)
        self.sigmoid = nn.Sigmoid()
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        f = x
        c1_ = (self.conv1(f))
        c1 = self.conv2(c1_)
        v_max = F.max_pool2d(c1, kernel_size=7, stride=3)
        v_range = self.relu(self.conv_max(v_max))
        c3 = self.relu(self.conv3(v_range))
        c3 = self.conv3_(c3)
        # print((x.size(2), x.size(3)))
        c3 = F.interpolate(c3, (x.size(2), x.size(3)), mode='bilinear', align_corners=None)
        cf = self.conv_f(c1_)
        c4 = self.conv4(c3 + cf)
        m = self.sigmoid(c4)

        return x * m


class RCAB2(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction=16,
                 bias=True, bn=False, act=nn.ReLU(True), res_scale=1):
        super(RCAB2, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)
        modules_body.append(CALayer(conv, n_feat, reduction))
        self.body = nn.Sequential(*modules_body)
        self.res_scale = res_scale

    def forward(self, x):
        res = self.body(x)
        # res += x
        return res


class RFA1(nn.Module):
    '''Residual Feature Aggregation'''

    def __init__(self,conv, n_feats, kernel_size, act=False):
        super(RFA, self).__init__()
        self.RFA1 = RCAB2(conv, n_feats, kernel_size)
        self.RFA2 = RCAB2(conv, n_feats, kernel_size)
        self.RFA3 = RCAB2(conv, n_feats, kernel_size)
        self.RFA4 = RCAB2(conv, n_feats, kernel_size)
        self.conv = nn.Conv2d(in_channels=n_feats * 4, out_channels=n_feats, kernel_size=1, stride=1, padding=0,
                              bias=False)
    def forward(self, x):
        ideti_data = x
        out_idn = []
        out1 = self.RFA1(x)
        out_idn.append(out1)

        x = torch.add(x, out1)
        out2 = self.RFA2(x)
        out_idn.append(out2)

        x = torch.add(x, out2)
        out3 = self.RFA3(x)
        out_idn.append(out3)

        x = torch.add(x, out3)
        out4 = self.RFA4(x)
        out4 = out4 + x
        out_idn.append(out4)

        out = torch.cat(out_idn, 1)
        out = out * 0.25
        out = self.conv(out)

        out = torch.add(out, ideti_data)
        return out


class RFA(nn.Module):
    '''Residual Feature Aggregation'''

    def __init__(self,conv, n_feats, kernel_size, act=False):
        super(RFA, self).__init__()
        self.RFA1 = RCAB2(conv, n_feats, kernel_size)
        self.RFA2 = RCAB2(conv, n_feats, kernel_size)
        self.RFA3 = RCAB2(conv, n_feats, kernel_size)
        self.RFA4 = RCAB2(conv, n_feats, kernel_size)
        self.conv2 = resnet.Bottleneck(n_feats,n_feats,radix=2,cardinality=2)
        self.conv = nn.Conv2d(in_channels=n_feats * 4, out_channels=n_feats, kernel_size=1, stride=1, padding=0,
                              bias=False)
    def forward(self, x):
        ideti_data = x
        out_idn = []
        out1 = self.RFA1(x)
        out_idn.append(out1)

        x = torch.add(x, out1)
        out2 = self.RFA2(x)
        out_idn.append(out2)

        x = torch.add(x, out2)
        out3 = self.RFA3(x)
        out_idn.append(out3)

        x = torch.add(x, out3)
        out4 = self.RFA4(x)
        out4 = out4 + x
        out_idn.append(out4)

        out = torch.cat(out_idn, 1)
        # out = out * 0.25

        out = self.conv(out)
        out = self.conv2(x)
        out = self.conv(out)
        out = torch.add(out, ideti_data)
        return out

class DRNF(nn.Module):
    '''Gloal Residual Feature Aggregation'''

    def __init__(self,conv, n_feats, kernel_size,n_blocks=16,act=False):
        super(DRNF, self).__init__()
        self.n_blocks = n_blocks
        self.RFA = RFA(conv, n_feats, kernel_size)
        self.conv = nn.Conv2d(in_channels=n_feats * n_blocks, out_channels=n_feats, kernel_size=1, stride=1, padding=0,
                              bias=False)
    def forward(self, x):
        ideti_data = x
        out = x
        out_idn = []
        # out_idn.append(out)
        for i in range(self.n_blocks):
            out = self.RFA(out)
            out_idn.append(out)
        out1 = torch.cat(out_idn,dim=1)
        out1 = self.conv(out1)
        out = out1 +ideti_data
        return out

class CASA(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction=16,
                 bias=True, bn=False, act=nn.ReLU(True), res_scale=1):
        super(CASA, self).__init__()
        self.conv1 = conv(n_feat, n_feat, kernel_size, bias=bias)
        self.act = act
        self.conv2 = conv(n_feat, n_feat, kernel_size, bias=bias)
        self.calyer = CALayer(conv, n_feat, reduction)
        # modules_body = []
        # for i in range(2):
        #     modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
        #     if bn: modules_body.append(nn.BatchNorm2d(n_feat))
        #     if i == 0: modules_body.append(act)
        # modules_body.append(CALayer(conv,n_feat, reduction))
        # self.body = nn.Sequential(*modules_body)
        # self.res_scale = res_scale
        self.salyer = ESA(n_feat)
        self.conv3 = nn.Conv2d(in_channels=n_feat * 2, out_channels=n_feat, kernel_size=1, stride=1, padding=0,
                               bias=False)

    def forward(self, x):
        # res = self.body(x)
        res = x
        out = self.conv1(res)
        out1 = self.act(out)
        out2 = self.conv2(out1)

        out3 = self.calyer(out2)
        out4 = self.salyer(out2)
        out5 = torch.cat((out3, out4), 1)

        out6 = self.conv3(out5)
        res = out6 + out2

        return res


class RB(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction=16,
                 bias=True, bn=False, act=nn.ReLU(True), res_scale=1):
        super(RB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)
        # modules_body.append(CALayer(conv, n_feat, reduction))
        self.body = nn.Sequential(*modules_body)
        self.res_scale = res_scale

    def forward(self, x):
        res = self.body(x)
        res += x
        return res

class CALayer8(nn.Module):
    def __init__(self, conv, channel, reduction=16):
        super(CALayer8, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0,bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // reduction, channel, 1, padding=0,bias=True),
            nn.Sigmoid()
        )

        self.conv2 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
                           bias=False)
        self.conv = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
                           bias=False)
        # self.conv3 = nn.Conv2d(in_channels=channel*2, out_channels=channel, kernel_size=1, stride=1, padding=0,
        #                       bias=False)
        self.conv4 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=2, dilation=2, bias=False)
        # self.conv7 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=3, dilation=3, bias=False)

        # self.salyer = ESA(channel)
        # self.pyconv = PyConv2(channel,channel)
    def forward(self, x):
        x1 = self.conv2(x)
        x2 = self.conv4(x)
        x3 = x1+x2
        y = self.avg_pool(x3)
        y = self.conv_du(y)
        z = x1 * y + x2 * (1-y)
        # z = self.conv(z)
        return z
class RCAB1(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction=16,
                 bias=True, bn=False, act=nn.ReLU(True), res_scale=1):
        super(RCAB1, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)
        modules_body.append(CALayer8(conv, n_feat, reduction))
        self.body = nn.Sequential(*modules_body)
        self.res_scale = res_scale

    def forward(self, x):
        res = self.body(x)
        # res += x
        return res

class RFASKNET(nn.Module):
    '''Residual Feature Aggregation'''

    def __init__(self,conv, n_feats, kernel_size, act=False):
        super(RFASKNET, self).__init__()
        self.RFA1 = RCAB(conv, n_feats, kernel_size)
        self.RFA2 = RCAB(conv, n_feats, kernel_size)
        self.RFA3 = RCAB(conv, n_feats, kernel_size)
        self.RFA4 = RCAB(conv, n_feats, kernel_size)
        self.conv = nn.Conv2d(in_channels=n_feats * 4, out_channels=n_feats, kernel_size=1, stride=1, padding=0,
                              bias=False)
    def forward(self, x):
        ideti_data = x

        out1 = self.RFA1(x)

        x = x + out1
        out2 = self.RFA2(x)

        x = x + out2
        out3 = self.RFA3(x)

        x = x + out3
        out4 = self.RFA4(x)

        out = torch.cat((out1,out2,out3,out4), 1)

        out = self.conv(out)
        out = torch.add(out, ideti_data)
        return out
class RRDBSK(nn.Module):
    '''Residual in Residual Dense Block'''

    def __init__(self, conv, nf, kernel_size, reduction=16,
                 bias=True, bn=False, act=nn.ReLU(True), res_scale=1, gc=32):
        super(RRDBSK, self).__init__()
        self.RDB1 = RFASKNET(conv, nf, kernel_size)
        self.RDB2 = RFASKNET(conv, nf, kernel_size)
        self.RDB3 = RFASKNET(conv, nf, kernel_size)
        self.RDB4 = RFASKNET(conv, nf, kernel_size)

        # self.conv2 = nn.Conv2d(in_channels=nf * 2, out_channels=nf, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv3 = nn.Conv2d(in_channels=nf * 3, out_channels=nf, kernel_size=1, stride=1, padding=0, bias=False)
        # self.conv4 = nn.Conv2d(in_channels=nf * 4, out_channels=nf, kernel_size=1, stride=1, padding=0, bias=False)

    def forward(self, x):

        out1 = self.RDB1(x)
        out1 = out1 + x

        out2 = self.RDB2(out1)
        out2 = out2 + out1

        out3 = self.RDB3(out2)
        out3 = out3 + out2

        out4 = self.RDB4(out3)
        out4 = out4 + out3

        # out =  torch.cat((out1,out2,out3,out4),1)
        # out = self.conv4(out)
        out = out4 + x
        return out

class MAFFD(nn.Module):
    def __init__(self, conv, channel, kernel_size, act=nn.ReLU(True), reduction=16):
        super(MAFFD, self).__init__()
        # global average pooling: feature --> point
        self.conv = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
                              bias=False)
        self.relu = nn.ReLU(True)
        self.conv2 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
                               bias=False)

        self.conv3 = nn.Conv2d(in_channels=channel, out_channels=channel * 4, kernel_size=1, stride=1, padding=0,
                               bias=False)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )
        self.avg_pool1 = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du1 = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

        # self.conv4 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=2, dilation=2, bias=False)
        #
        # self.conv5 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
        #                       bias=False)
        # self.conv7 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=3, dilation=3, bias=False)

        # self.salyer = ESA(channel)
        # self.pyconv = PyConv2(channel,channel)

    def forward(self, x):
        x1 = self.conv(x)
        x1 = self.relu(x1)
        x1 = self.conv2(x1)
        # x1 = self.relu(x1)
        x1 = self.conv3(x1)
        x1, x2, x5, x6 = torch.split(x1, 64, dim=1)
        # x1 = self.conv4(x1)
        # x2 = self.conv5(x2)
        x3 = x1 + x2

        y = self.avg_pool(x3)
        y = self.conv_du(y)
        z = x1 * y + x2 * (1 - y)

        x7 = x5 + x6
        y1 = self.avg_pool1(x7)
        y1 = self.conv_du1(y1)
        z1 = x5 * y1 + x6 * (1 - y1)

        z = z1 + z
        return z
class PA(nn.Module):
    '''PA is pixel attention'''
    def __init__(self, nf):

        super(PA, self).__init__()
        self.conv = nn.Conv2d(nf, nf, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):

        y = self.conv(x)
        y = self.sigmoid(y)
        out = torch.mul(x, y)

        return out
class MAFFD2(nn.Module):
    def __init__(self, conv, channel, kernel_size, act=nn.ReLU(True), reduction=16):
        super(MAFFD2, self).__init__()
        # global average pooling: feature --> point

        self.conv3 = nn.Conv2d(in_channels=channel, out_channels=channel * 2, kernel_size=1, stride=1, padding=0,
                               bias=False)
        # self.conv4 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=2, dilation=2, bias=False)

        self.conv5 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
                              bias=False)
        self.conv6 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
                               bias=False)
        self.conv7 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
                               bias=False)
        self.PA = PA(channel)
        # self.conv = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
        #                       bias=False)
        # self.relu = nn.ReLU(True)
        # self.conv2 = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=3, stride=1, padding=1,
        #                        bias=False)

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )
        # self.avg_pool1 = nn.AdaptiveAvgPool2d(1)
        # # feature channel downscale and upscale --> channel weight
        # self.conv_du1 = nn.Sequential(
        #     nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
        #     nn.ReLU(inplace=True),
        #     nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
        #     nn.Sigmoid()
        # )


        # self.conv7 = nn.Conv2d(channel, channel, kernel_size=3, stride=1, padding=3, dilation=3, bias=False)

        # self.salyer = ESA(channel)
        # self.pyconv = PyConv2(channel,channel)

    def forward(self, x):

        # x1 = self.relu(x1)
        x1 = self.conv3(x)
        x1, x2 = torch.split(x1, 20, dim=1)
        x1 = self.conv5(x1)

        x2 = self.conv6(x2)
        x2 = self.PA(x2)
        x2 = self.conv7(x2)
        x3 = x1 + x2

        y = self.avg_pool(x3)
        y = self.conv_du(y)
        z = x1 * y + x2 * (1 - y)

        # x7 = x5 + x6
        # y1 = self.avg_pool1(x7)
        # y1 = self.conv_du1(y1)
        # z1 = x5 * y1 + x6 * (1 - y1)
        #
        # z = z1 + z
        z = z + x

        return z
class ResidualDenseBlock_5C(nn.Module):
    def __init__(self, nf=64, gc=32, bias=True):
        super(ResidualDenseBlock_5C, self).__init__()
        # gc: growth channel, i.e. intermediate channels
        self.conv1 = nn.Conv2d(nf, gc, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(nf + gc, gc, 3, 1, 1, bias=bias)
        self.conv3 = nn.Conv2d(nf + 2 * gc, gc, 3, 1, 1, bias=bias)
        self.conv4 = nn.Conv2d(nf + 3 * gc, gc, 3, 1, 1, bias=bias)
        self.conv5 = nn.Conv2d(nf + 4 * gc, nf, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)  ##查查nn.LeakyReLU的参数意思

        # initialization
        mutil.initialize_weights([self.conv1, self.conv2, self.conv3, self.conv4, self.conv5], 0.1)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))   ## torch.cat(x,x1)拼接x，x1增加列
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5 * 0.2 + x


class RRDB(nn.Module):
    '''Residual in Residual Dense Block'''

    def __init__(self, nf, gc=32):
        super(RRDB, self).__init__()
        self.RDB1 = ResidualDenseBlock_5C(nf, gc)
        self.RDB2 = ResidualDenseBlock_5C(nf, gc)
        self.RDB3 = ResidualDenseBlock_5C(nf, gc)

    def forward(self, x):
        out = self.RDB1(x)
        out = self.RDB2(out)
        out = self.RDB3(out)
        return out * 0.2 + x

class RRDBNet(nn.Module):
    def __init__(self,gc=32):
        super(RRDBNet, self).__init__()
        in_nc = 3
        out_nc=3
        nf = 64
        nb = 3
        gc = 32
        RRDB_block_f = functools.partial(RRDB, nf=nf, gc=gc)

        self.conv_first = nn.Conv2d(in_nc, nf, 3, 1, 1, bias=True)
        self.RRDB_trunk = mutil.make_layer(RRDB_block_f, nb)  # self.RRDB_trunk是23个RRDB，RRDB包括（RRDB1,RRDB2,RRDB3）而RRDB1又包括是一个密集连接块，RRDB2,RRDB3也是同理
        self.trunk_conv = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        #### upsampling
        # self.upconv1 = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        # self.upconv2 = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        # self.HRconv = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        # self.conv_last = nn.Conv2d(nf, out_nc, 3, 1, 1, bias=True)
        #
        # self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

    def forward(self, x):
        # fea = self.conv_first(x)
        trunk = self.trunk_conv(self.RRDB_trunk(x))
        out = x + trunk

        # fea = self.lrelu(self.upconv1(F.interpolate(fea, scale_factor=2, mode='nearest'))) ##F.interpolate上采样函数其中scale_factor=2是放大两倍
        # fea = self.lrelu(self.upconv2(F.interpolate(fea, scale_factor=2, mode='nearest')))
        # out = self.conv_last(self.lrelu(self.HRconv(fea)))

        return out

class FeedbackBlock(nn.Module):
    def __init__(self, num_features, num_groups, upscale_factor, act_type, norm_type):
        super(FeedbackBlock, self).__init__()
        if upscale_factor == 2:
            stride = 2
            padding = 2
            kernel_size = 6
        elif upscale_factor == 3:
            stride = 3
            padding = 2
            kernel_size = 7
        elif upscale_factor == 4:
            stride = 4
            padding = 2
            kernel_size = 8
        elif upscale_factor == 8:
            stride = 8
            padding = 2
            kernel_size = 12

        self.num_groups = num_groups

        self.compress_in = ConvBlock(2*num_features, num_features,
                                     kernel_size=1,
                                     act_type=act_type, norm_type=norm_type)

        # self.upBlocks = nn.ModuleList()
        # self.downBlocks = nn.ModuleList()
        # self.uptranBlocks = nn.ModuleList()
        # self.downtranBlocks = nn.ModuleList()
        #
        # for idx in range(self.num_groups):
        #     self.upBlocks.append(DeconvBlock(num_features, num_features,
        #                                      kernel_size=kernel_size, stride=stride, padding=padding,
        #                                      act_type=act_type, norm_type=norm_type))
        #     self.downBlocks.append(ConvBlock(num_features, num_features,
        #                                      kernel_size=kernel_size, stride=stride, padding=padding,
        #                                      act_type=act_type, norm_type=norm_type, valid_padding=False))
        #     if idx > 0:
        #         self.uptranBlocks.append(ConvBlock(num_features*(idx+1), num_features,
        #                                            kernel_size=1, stride=1,
        #                                            act_type=act_type, norm_type=norm_type))
        #         self.downtranBlocks.append(ConvBlock(num_features*(idx+1), num_features,
        #                                              kernel_size=1, stride=1,
        #                                              act_type=act_type, norm_type=norm_type))
        #
        # self.compress_out = ConvBlock(num_groups*num_features, num_features,
        #                               kernel_size=1,
        #                               act_type=act_type, norm_type=norm_type)

        self.should_reset = True
        self.last_hidden = None
        self.RRDBNet = RRDBNet()
        # self.RRDB1 = RRDB(64,32)
        # self.RRDB2 = RRDB(64,32)
        self.ca = CALayer(64, 16)
    def forward(self, x):
        if self.should_reset:
            self.last_hidden = torch.zeros(x.size()).cuda()
            self.last_hidden.copy_(x)
            self.should_reset = False

        x = torch.cat((x, self.last_hidden), dim=1)
        x = self.compress_in(x)

        # lr_features = []
        # hr_features = []
        # lr_features.append(x)
        # x = self.RRDB1(x)
        output = self.RRDBNet(x)
        # for idx in range(self.num_groups):

        #     LD_L = torch.cat(tuple(lr_features), 1)    # when idx == 0, lr_features == [x]
        #     if idx > 0:
        #         LD_L = self.uptranBlocks[idx-1](LD_L)
        #     LD_H = self.upBlocks[idx](LD_L)
        #
        #     hr_features.append(LD_H)
        #
        #     LD_H = torch.cat(tuple(hr_features), 1)
        #     if idx > 0:
        #         LD_H = self.downtranBlocks[idx-1](LD_H)
        #     LD_L = self.downBlocks[idx](LD_H)
        #
        #     lr_features.append(LD_L)
        #
        # del hr_features
        # output = torch.cat(tuple(lr_features[1:]), 1)   # leave out input x, i.e. lr_features[0]
        # output = self.compress_out(output)

        output = self.ca(output)
        # output = output + x
        self.last_hidden = output
        return output

    def reset_state(self):
        self.should_reset = True


class SRFBN(nn.Module):
    def __init__(self,  conv, n_feats, kernel_size, act=False):
        super(SRFBN, self).__init__()
        in_channels = 3
        out_channels = 3
        num_features = 64
        num_steps = 4
        num_groups = 3
        upscale_factor = 2
        act_type = 'prelu'
        norm_type = None
        if upscale_factor == 2:
            stride = 2
            padding = 2
            kernel_size = 6
        elif upscale_factor == 3:
            stride = 3
            padding = 2
            kernel_size = 7
        elif upscale_factor == 4:
            stride = 4
            padding = 2
            kernel_size = 8
        elif upscale_factor == 8:
            stride = 8
            padding = 2
            kernel_size = 12

        self.num_steps = num_steps
        self.num_features = num_features
        self.upscale_factor = upscale_factor


        # LR feature extraction block
        self.conv_in = ConvBlock(64, 4 * num_features,
                                 kernel_size=3,
                                 act_type=act_type, norm_type=norm_type)
        self.feat_in = ConvBlock(4 * num_features, num_features,
                                 kernel_size=1,
                                 act_type=act_type, norm_type=norm_type)

        # basic block
        self.block = FeedbackBlock(num_features, num_groups, upscale_factor, act_type, norm_type)

        # reconstruction block
        # uncomment for pytorch 0.4.0
        # self.upsample = nn.Upsample(scale_factor=upscale_factor, mode='bilinear')

        self.out = DeconvBlock(num_features, num_features,
                               kernel_size=kernel_size, stride=stride, padding=padding,
                               act_type='prelu', norm_type=norm_type)
        self.conv_out = ConvBlock(num_features, 64,
                                  kernel_size=3,
                                  act_type=None, norm_type=norm_type)


    def forward(self, x):
        self._reset_state()

        # uncomment for pytorch 0.4.0
        # inter_res = self.upsample(x)

        # comment for pytorch 0.4.0
        inter_res = nn.functional.interpolate(x, scale_factor=self.upscale_factor, mode='bilinear', align_corners=False)

        x = self.conv_in(x)
        x = self.feat_in(x)

        outs = []
        for _ in range(self.num_steps):
            h = self.block(x)
            h = torch.add(inter_res, self.conv_out(self.out(h)))
            outs.append(h)

        return outs  # return output of every timesteps

    def _reset_state(self):
        self.block.reset_state()
class RFAMFF(nn.Module):
    '''Residual Feature Aggregation'''

    def __init__(self, conv, n_feats, kernel_size, act=False):
        super(RFAMFF, self).__init__()
        self.RFA1 = MAFFD(conv, n_feats, kernel_size)
        self.RFA2 = MAFFD(conv, n_feats, kernel_size)
        self.RFA3 = MAFFD(conv, n_feats, kernel_size)
        # self.RFA4 = MAFFD(conv, n_feats, kernel_size)
        self.conv = nn.Conv2d(in_channels=n_feats * 3, out_channels=n_feats, kernel_size=1, stride=1, padding=0,
                              bias=False)

    def forward(self, x):
        ideti_data = x

        out1 = self.RFA1(x)

        x = x + out1
        out2 = self.RFA2(x)

        x = x + out2
        out3 = self.RFA3(x)

        # x = x + out3
        # out4 = self.RFA4(x)

        # out = torch.cat((out1,out2,out3,out4), 1)
        out = torch.cat((out1, out2, out3), 1)

        out = self.conv(out)
        out = torch.add(out, ideti_data)

        return out

