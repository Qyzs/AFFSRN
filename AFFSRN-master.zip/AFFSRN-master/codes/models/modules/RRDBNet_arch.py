import functools
import torch
import torch.nn as nn
import torch.nn.functional as F
import models.modules.module_util as mutil

from torch.nn import functional as F
from .blocks import ConvBlock, DeconvBlock, MeanShift

class ResidualDenseBlock_5C(nn.Module):
    def __init__(self, nf=64, gc=32, bias=True):
        super(ResidualDenseBlock_5C, self).__init__()
        # gc: growth channel, i.e. intermediate channels
        self.conv1 = nn.Conv2d(nf, gc, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(nf + gc, gc, 3, 1, 1, bias=bias)
        self.conv3 = nn.Conv2d(nf + 2 * gc, gc, 3, 1, 1, bias=bias)
        self.conv4 = nn.Conv2d(nf + 3 * gc, gc, 3, 1, 1, bias=bias)
        self.conv5 = nn.Conv2d(nf + 4 * gc, nf, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)  ##查查nn.LeakyReLU的参数意思

        # initialization
        mutil.initialize_weights([self.conv1, self.conv2, self.conv3, self.conv4, self.conv5], 0.1)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))   ## torch.cat(x,x1)拼接x，x1增加列
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5 * 0.2 + x


class RRDB(nn.Module):
    '''Residual in Residual Dense Block'''

    def __init__(self, nf, gc=32):
        super(RRDB, self).__init__()
        self.RDB1 = ResidualDenseBlock_5C(nf, gc)
        self.RDB2 = ResidualDenseBlock_5C(nf, gc)
        self.RDB3 = ResidualDenseBlock_5C(nf, gc)

    def forward(self, x):
        out = self.RDB1(x)
        out = self.RDB2(out)
        out = self.RDB3(out)
        return out * 0.2 + x


class RRDBNet(nn.Module):
    def __init__(self, in_nc, out_nc, nf, nb, gc=32):
        super(RRDBNet, self).__init__()
        RRDB_block_f = functools.partial(RRDB, nf=nf, gc=gc)

        self.conv_first = nn.Conv2d(in_nc, nf, 3, 1, 1, bias=True)
        self.RRDB_trunk = mutil.make_layer(RRDB_block_f, nb)  # self.RRDB_trunk是23个RRDB，RRDB包括（RRDB1,RRDB2,RRDB3）而RRDB1又包括是一个密集连接块，RRDB2,RRDB3也是同理
        self.trunk_conv = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        #### upsampling
        self.upconv1 = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        self.upconv2 = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        self.HRconv = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        self.conv_last = nn.Conv2d(nf, out_nc, 3, 1, 1, bias=True)

        self.lrelu = nn.LeakyReLU(negative_slope=0.2, inplace=True)

    def forward(self, x):
        fea = self.conv_first(x)
        trunk = self.trunk_conv(self.RRDB_trunk(fea))
        fea = fea + trunk

        fea = self.lrelu(self.upconv1(F.interpolate(fea, scale_factor=2, mode='nearest'))) ##F.interpolate上采样函数其中scale_factor=2是放大两倍
        fea = self.lrelu(self.upconv2(F.interpolate(fea, scale_factor=2, mode='nearest')))
        out = self.conv_last(self.lrelu(self.HRconv(fea)))

        return out
import torch
import torch.nn as nn
from models.modules import common


def make_model(opt):
    return DRN(opt)


class DRN2(nn.Module):
    def __init__(self, in_nc, out_nc, nf, nb):
        super(DRN2, self).__init__()
        self.scale = [2,4]
        self.phase = 2
        n_blocks = 1
        n_feats = 16
        kernel_size = 3
        self.rgb_range = 255
        act = nn.ReLU(True)
        self.n_colors = out_nc
        self.upsample = nn.Upsample(scale_factor=max(self.scale),
                                    mode='bicubic', align_corners=False)

        rgb_mean = (0.4488, 0.4371, 0.4040)
        rgb_std = (1.0, 1.0, 1.0)
        self.sub_mean = common.MeanShift(self.rgb_range, rgb_mean, rgb_std)

        self.head = common.default_conv(out_nc, n_feats, kernel_size)

        self.down = [
            common.DownBlock(self, 2, n_feats * pow(2, p), n_feats * pow(2, p), n_feats * pow(2, p + 1)
            ) for p in range(self.phase)
        ]

        self.down = nn.ModuleList(self.down)

        self.down2 = [
            common.DownBlock2(self, 2, n_feats * pow(2, p), n_feats * pow(2, p), n_feats * pow(2, p + 1)
                             ) for p in range(self.phase)
        ]

        self.down2 = nn.ModuleList(self.down2)

        up_body_blocks = [[
            common.SRFBN(
                common.default_conv, n_feats * pow(2, p), kernel_size, act=act
            ) for _ in range(n_blocks)
        ] for p in range(self.phase, 1, -1)
        ]

        up_body_blocks.insert(0, [
            common.SRFBN(
                common.default_conv, n_feats * pow(2, self.phase), kernel_size, act=act
            ) for _ in range(n_blocks)
        ])

        # The fisrt upsample block
        up = [[
            # common.Upsampler(common.default_conv, 2, n_feats * pow(2, self.phase), act=False),
            common.default_conv(n_feats * pow(2, self.phase), n_feats * pow(2, self.phase - 1), kernel_size=1)
        ]]

        # The rest upsample blocks
        for p in range(self.phase - 1, 0, -1):
            up.append([
                # common.Upsampler(common.default_conv, 2, 2 * n_feats * pow(2, p), act=False),
                common.default_conv(2 * n_feats * pow(2, p), n_feats * pow(2, p - 1), kernel_size=1)
            ])

        self.up_blocks1 = nn.ModuleList()
        for idx in range(self.phase):
            self.up_blocks1.append(
                nn.Sequential(*up_body_blocks[idx])
            )
        self.up_blocks2 = nn.ModuleList()
        for idx in range(self.phase):
            self.up_blocks2.append(
                nn.Sequential(*up[idx])
            )

        # tail conv that output sr imgs
        tail = [common.default_conv(n_feats * pow(2, self.phase), self.n_colors, kernel_size)]
        for p in range(self.phase, 0, -1):
            tail.append(
                common.default_conv(n_feats * pow(2, p), self.n_colors, kernel_size)
            )
        self.tail = nn.ModuleList(tail)

        self.add_mean = common.MeanShift(self.rgb_range, rgb_mean, rgb_std, 1)

        self.conv1 = nn.Conv2d(32, 16, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv2 = nn.Conv2d(32 ,3, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv3 = nn.Conv2d(64, 3, kernel_size=3, stride=1, padding=1, bias=False)

    def forward(self, x):
        # upsample x to target sr size
        x = self.upsample(x)

        # preprocess
        # x = self.sub_mean(x)
        x = self.head(x)

        # down phases,
        copies = []
        for idx in range(self.phase):
            copies.append(x)
            x = self.down[idx](x)

        # up phases
        sr = self.tail[0](x)
        sr0 = self.add_mean(sr)
        results = [sr]
        for idx in range(self.phase):
            # upsample to SR features
            if idx == 0:
                outs = self.up_blocks1[idx](x)
                fb0 = outs[0]
                fb1 = outs[1]
                fb2 = outs[2]
                x = outs[-1]
                x = self.up_blocks2[idx](x)
                # concat down features and upsample features
                x = torch.cat((x, copies[self.phase - idx - 1]), 1)
                # output sr imgs

                sr1 = self.tail[idx + 1](x)
            if idx == 1:
                outs = self.up_blocks1[idx](x)
                fb00 = outs[0]
                fb11 = outs[1]
                fb22 = outs[2]
                x = outs[-1]
                x = self.up_blocks2[idx](x)
                # concat down features and upsample features
                x = torch.cat((x, copies[self.phase - idx - 1]), 1)
                sr2 = self.tail[idx + 1](x)

        copies1 = []
        x = self.conv1(x)
        for idx in range(self.phase):
            x = self.down2[idx](x)
            copies1.append(x)
        sr2lr0 = copies1[0]
        sr2lr0 = self.conv2(sr2lr0)
        fb00 = self.conv3(fb00)
        fb11 = self.conv3(fb11)
        fb22 = self.conv3(fb22)
        sr2lr1 = copies1[1]
        sr2lr1 = self.conv3(sr2lr1)
        fb0 = self.conv3(fb0)
        fb1 = self.conv3(fb1)
        fb2 = self.conv3(fb2)
        return sr0,sr1,sr2,fb0,fb1,fb2,fb00,fb11,fb22,sr2lr0,sr2lr1

class FeedbackBlock(nn.Module):
    def __init__(self, num_features, num_groups, upscale_factor, act_type, norm_type):
        super(FeedbackBlock, self).__init__()
        if upscale_factor == 2:
            stride = 2
            padding = 2
            kernel_size = 6
        elif upscale_factor == 3:
            stride = 3
            padding = 2
            kernel_size = 7
        elif upscale_factor == 4:
            stride = 4
            padding = 2
            kernel_size = 8
        elif upscale_factor == 8:
            stride = 8
            padding = 2
            kernel_size = 12

        self.num_groups = num_groups
        self.upsample = nn.Upsample(scale_factor=max(self.scale),
                                    mode='bicubic', align_corners=False)

        self.compress_in = ConvBlock(2*num_features, num_features,
                                     kernel_size=1,
                                     act_type=act_type, norm_type=norm_type)

        self.upBlocks = nn.ModuleList()
        self.downBlocks = nn.ModuleList()
        self.uptranBlocks = nn.ModuleList()
        self.downtranBlocks = nn.ModuleList()

        for idx in range(self.num_groups):
            self.upBlocks.append(DeconvBlock(num_features, num_features,
                                             kernel_size=kernel_size, stride=stride, padding=padding,
                                             act_type=act_type, norm_type=norm_type))
            self.downBlocks.append(ConvBlock(num_features, num_features,
                                             kernel_size=kernel_size, stride=stride, padding=padding,
                                             act_type=act_type, norm_type=norm_type, valid_padding=False))
            if idx > 0:
                self.uptranBlocks.append(ConvBlock(num_features*(idx+1), num_features,
                                                   kernel_size=1, stride=1,
                                                   act_type=act_type, norm_type=norm_type))
                self.downtranBlocks.append(ConvBlock(num_features*(idx+1), num_features,
                                                     kernel_size=1, stride=1,
                                                     act_type=act_type, norm_type=norm_type))

        self.compress_out = ConvBlock(num_groups*num_features, num_features,
                                      kernel_size=1,
                                      act_type=act_type, norm_type=norm_type)

        self.should_reset = True
        self.last_hidden = None

    def forward(self, x):
        if self.should_reset:
            self.last_hidden = torch.zeros(x.size()).cuda()
            self.last_hidden.copy_(x)
            self.should_reset = False

        x = torch.cat((x, self.last_hidden), dim=1)
        x = self.compress_in(x)

        lr_features = []
        hr_features = []
        lr_features.append(x)

        for idx in range(self.num_groups):
            LD_L = torch.cat(tuple(lr_features), 1)    # when idx == 0, lr_features == [x]
            if idx > 0:
                LD_L = self.uptranBlocks[idx-1](LD_L)
            LD_H = self.upBlocks[idx](LD_L)

            hr_features.append(LD_H)

            LD_H = torch.cat(tuple(hr_features), 1)
            if idx > 0:
                LD_H = self.downtranBlocks[idx-1](LD_H)
            LD_L = self.downBlocks[idx](LD_H)

            lr_features.append(LD_L)

        del hr_features
        output = torch.cat(tuple(lr_features[1:]), 1)   # leave out input x, i.e. lr_features[0]
        output = self.compress_out(output)

        self.last_hidden = output

        return output

    def reset_state(self):
        self.should_reset = True


class SRFBN(nn.Module):
    def __init__(self,  conv, n_feats, kernel_size, act=False):
        super(SRFBN, self).__init__()
        in_channels = 3
        out_channels = 3
        num_features = 32
        num_steps = 4
        num_groups = 3
        upscale_factor = 2
        act_type = 'prelu'
        norm_type = None
        if upscale_factor == 2:
            stride = 2
            padding = 2
            kernel_size = 6
        elif upscale_factor == 3:
            stride = 3
            padding = 2
            kernel_size = 7
        elif upscale_factor == 4:
            stride = 4
            padding = 2
            kernel_size = 8
        elif upscale_factor == 8:
            stride = 8
            padding = 2
            kernel_size = 12

        self.num_steps = num_steps
        self.num_features = num_features
        self.upscale_factor = upscale_factor


        # LR feature extraction block
        self.conv_in = ConvBlock(64, 4 * num_features,
                                 kernel_size=3,
                                 act_type=act_type, norm_type=norm_type)
        self.feat_in = ConvBlock(4 * num_features, num_features,
                                 kernel_size=1,
                                 act_type=act_type, norm_type=norm_type)

        # basic block
        self.block = FeedbackBlock(num_features, num_groups, upscale_factor, act_type, norm_type)

        # reconstruction block
        # uncomment for pytorch 0.4.0
        # self.upsample = nn.Upsample(scale_factor=upscale_factor, mode='bilinear')

        self.out = DeconvBlock(num_features, num_features,
                               kernel_size=kernel_size, stride=stride, padding=padding,
                               act_type='prelu', norm_type=norm_type)
        self.conv_out = ConvBlock(num_features, 64,
                                  kernel_size=3,
                                  act_type=None, norm_type=norm_type)


    def forward(self, x):
        self._reset_state()

        # uncomment for pytorch 0.4.0
        # inter_res = self.upsample(x)

        # comment for pytorch 0.4.0
        inter_res = nn.functional.interpolate(x, scale_factor=self.upscale_factor, mode='bilinear', align_corners=False)

        x = self.conv_in(x)
        x = self.feat_in(x)

        outs = []
        for _ in range(self.num_steps):
            h = self.block(x)
            h = torch.add(inter_res, self.conv_out(self.out(h)))
            outs.append(h)

        return outs  # return output of every timesteps

    def _reset_state(self):
        self.block.reset_state()



import torch
from torch import nn, einsum
from einops import rearrange, repeat


class CyclicShift(nn.Module):
    def __init__(self, displacement):
        super().__init__()
        self.displacement = displacement

    def forward(self, x):
        return torch.roll(x, shifts=(self.displacement, self.displacement), dims=(1, 2))


class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(x, **kwargs) + x


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, dim),
        )

    def forward(self, x):
        return self.net(x)


def create_mask(window_size, displacement, upper_lower, left_right):
    mask = torch.zeros(window_size ** 2, window_size ** 2)

    if upper_lower:
        mask[-displacement * window_size:, :-displacement * window_size] = float('-inf')
        mask[:-displacement * window_size, -displacement * window_size:] = float('-inf')

    if left_right:
        mask = rearrange(mask, '(h1 w1) (h2 w2) -> h1 w1 h2 w2', h1=window_size, h2=window_size)
        mask[:, -displacement:, :, :-displacement] = float('-inf')
        mask[:, :-displacement, :, -displacement:] = float('-inf')
        mask = rearrange(mask, 'h1 w1 h2 w2 -> (h1 w1) (h2 w2)')

    return mask


class WindowAttention(nn.Module):
    def __init__(self, dim, heads, head_dim, shifted, window_size=7):
        super().__init__()
        inner_dim = head_dim * heads

        self.heads = heads
        self.scale = head_dim ** -0.5
        self.window_size = window_size
        self.shifted = shifted

        if self.shifted:
            displacement = window_size // 2
            self.cyclic_shift = CyclicShift(-displacement)
            self.cyclic_back_shift = CyclicShift(displacement)
            self.upper_lower_mask = nn.Parameter(create_mask(window_size=window_size, displacement=displacement,
                                                             upper_lower=True, left_right=False), requires_grad=False)
            self.left_right_mask = nn.Parameter(create_mask(window_size=window_size, displacement=displacement,
                                                            upper_lower=False, left_right=True), requires_grad=False)

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)
        self.pos_embedding = nn.Parameter(torch.randn(self.window_size ** 2, self.window_size ** 2))  # 位置编码
        self.to_out = nn.Linear(inner_dim, dim)

    def forward(self, x):
        if self.shifted:
            x = self.cyclic_shift(x)

        b, n_h, n_w, _, h = *x.shape, self.heads

        qkv = self.to_qkv(x).chunk(3, dim=-1)
        nw_h = n_h // self.window_size
        nw_w = n_w // self.window_size

        q, k, v = map(
            lambda t: rearrange(t, 'b (nw_h w_h) (nw_w w_w) (h d) -> b h (nw_h nw_w) (w_h w_w) d',
                                h=h, w_h=self.window_size, w_w=self.window_size), qkv)

        dots = einsum('b h w i d, b h w j d -> b h w i j', q, k) * self.scale
        dots += self.pos_embedding

        if self.shifted:
            dots[:, :, -nw_w:] += self.upper_lower_mask
            dots[:, :, nw_w - 1::nw_w] += self.left_right_mask

        attn = dots.softmax(dim=-1)

        out = einsum('b h w i j, b h w j d -> b h w i d', attn, v)
        out = rearrange(out, 'b h (nw_h nw_w) (w_h w_w) d -> b (nw_h w_h) (nw_w w_w) (h d)',
                        h=h, w_h=self.window_size, w_w=self.window_size, nw_h=nw_h, nw_w=nw_w)
        out = self.to_out(out)

        if self.shifted:
            out = self.cyclic_back_shift(out)
        return out


class SwinBlock(nn.Module):
    def __init__(self, dim, heads, head_dim, mlp_dim, shifted, window_size):
        super().__init__()
        self.attention_block = Residual(PreNorm(dim, WindowAttention(dim=dim,
                                                                     heads=heads,
                                                                     head_dim=head_dim,
                                                                     shifted=shifted,
                                                                     window_size=window_size)))
        self.mlp_block = Residual(PreNorm(dim, FeedForward(dim=dim, hidden_dim=mlp_dim)))

    def forward(self, x):
        x = self.attention_block(x)
        x = self.mlp_block(x)
        return x


class PatchMerging(nn.Module):
    def __init__(self, in_channels, out_channels, downscaling_factor):
        super().__init__()
        self.downscaling_factor = downscaling_factor
        self.patch_merge = nn.Unfold(kernel_size=downscaling_factor, stride=downscaling_factor, padding=0)
        self.linear = nn.Linear(in_channels * downscaling_factor ** 2, out_channels)

    def forward(self, x):
        b, c, h, w = x.shape
        new_h, new_w = h // self.downscaling_factor, w // self.downscaling_factor
        x = self.patch_merge(x).view(b, -1, new_h, new_w).permute(0, 2, 3, 1)
        x = self.linear(x) # 维度 调整
        return x

######  尺寸控制
class UnpatchMerging(nn.Module):
    def __init__(self, in_channels, out_channels,outsize, downscaling_factor):
        super().__init__()
        self.downscaling_factor = downscaling_factor
        self.linear = nn.Linear(in_channels, out_channels)
        self.patch_merge = nn.Fold(output_size=outsize,kernel_size=downscaling_factor, stride=downscaling_factor)

    def forward(self, x):
        b,nh,nw,c = x.shape
        x = self.linear(x) # 维度 调整
        x = self.patch_merge(x.permute(0, 3, 1, 2).view(b,c//4,-1))
        return x





class StageModule_源码(nn.Module):
    def __init__(self, in_channels, hidden_dimension, layers, downscaling_factor, num_heads, head_dim, window_size):
        super().__init__()
        assert layers % 2 == 0, 'Stage layers need to be divisible by 2 for regular and shifted block.'

        self.patch_partition = PatchMerging(in_channels=in_channels, out_channels=hidden_dimension,
                                            downscaling_factor=downscaling_factor)

        self.layers = nn.ModuleList([])
        for _ in range(layers // 2):
            self.layers.append(nn.ModuleList([
                SwinBlock(dim=hidden_dimension, heads=num_heads, head_dim=head_dim, mlp_dim=hidden_dimension * 4,
                          shifted=False, window_size=window_size),
                SwinBlock(dim=hidden_dimension, heads=num_heads, head_dim=head_dim, mlp_dim=hidden_dimension * 4,
                          shifted=True, window_size=window_size),
            ]))

    def forward(self, x):
        x = self.patch_partition(x)
        for regular_block, shifted_block in self.layers:
            x = regular_block(x)
            x = shifted_block(x)
        return x.permute(0, 3, 1, 2)

class backbone(nn.Module):
    def __init__(self, hidden_dimension,out_dimension, num_heads, head_dim, window_size):
        super().__init__()

        self.sw1 = SwinBlock(dim=hidden_dimension, heads=num_heads, head_dim=head_dim, mlp_dim=hidden_dimension * 4,
                  shifted=False, window_size=window_size)  # W-MSA
        self.sw2 = SwinBlock(dim=hidden_dimension, heads=num_heads, head_dim=head_dim, mlp_dim=hidden_dimension * 4,
                  shifted=True, window_size=window_size)  # SW-MSA

        self.linear = nn.Linear(hidden_dimension,out_dimension)

    def forward(self,x):
       x = self.sw1(x)
       x = self.sw2(x)
       x = self.linear(x)  # 维度 调整

       return x




class StageModule(nn.Module):
    def __init__(self, in_channels, hidden_dimension, layers, downscaling_factor, num_heads, head_dim, window_size,image_size,gc=24):
        super().__init__()
        assert layers % 2 == 0, 'Stage layers need to be divisible by 2 for regular and shifted block.'

        self.patch_partition = PatchMerging(in_channels=in_channels, out_channels=hidden_dimension,
                                            downscaling_factor=downscaling_factor)
        self.unpatch_partiton = UnpatchMerging(in_channels=hidden_dimension,out_channels=hidden_dimension//(hidden_dimension//(downscaling_factor*downscaling_factor*3)),outsize=image_size,downscaling_factor=downscaling_factor)


        self.b1 = backbone(hidden_dimension,gc, num_heads, head_dim, window_size)
        self.b2 = backbone(hidden_dimension+gc,gc ,num_heads, head_dim, window_size)
        self.b3 = backbone(hidden_dimension+2*gc, gc ,num_heads, head_dim, window_size)
        self.b4 = backbone(hidden_dimension+3*gc,gc , num_heads, head_dim, window_size)
        self.b5 = backbone(hidden_dimension+4*gc,hidden_dimension , num_heads, head_dim, window_size)

        # self.should_reset = True
        # self.last_hidden = None
        #
        # self.compress_in =  nn.Conv2d(6, 3, kernel_size=1, stride=1, padding=0, bias=False),
    def forward(self, x):
        # if self.should_reset:
        #     self.last_hidden = torch.zeros(x.size()).cuda()
        #     self.last_hidden.copy_(x)
        #     self.should_reset = False
        #
        # x = x + self.last_hidden


        x = self.patch_partition(x)
        # for regular_block, shifted_block in self.layers:
        #     x = regular_block(x)
        #     x = shifted_block(x)
        x1 = self.b1(x)
        x2 = self.b2(torch.cat((x,x1),3))
        x3 = self.b3(torch.cat((x,x1,x2), 3))
        x4 = self.b4(torch.cat((x, x1,x2,x3), 3))
        x5 = self.b5(torch.cat((x, x1,x2,x3,x4), 3))
        x = self.unpatch_partiton(x5)
        return x

# class StageModule(nn.Module):
#     def __init__(self, in_channels, hidden_dimension, layers, downscaling_factor, num_heads, head_dim, window_size,image_size):
#         super().__init__()
#         assert layers % 2 == 0, 'Stage layers need to be divisible by 2 for regular and shifted block.'
#
#         self.patch_partition = PatchMerging(in_channels=in_channels, out_channels=hidden_dimension,
#                                             downscaling_factor=downscaling_factor)
#         self.unpatch_partiton = UnpatchMerging(in_channels=hidden_dimension,out_channels=hidden_dimension//(hidden_dimension//(downscaling_factor*downscaling_factor*3)),outsize=image_size,downscaling_factor=downscaling_factor)
#
#         self.layers = nn.ModuleList([])
#         for _ in range(layers // 2):
#             self.layers.append(nn.ModuleList([
#                 SwinBlock(dim=hidden_dimension, heads=num_heads, head_dim=head_dim, mlp_dim=hidden_dimension * 4,
#                           shifted=False, window_size=window_size), # W-MSA
#                 SwinBlock(dim=hidden_dimension, heads=num_heads, head_dim=head_dim, mlp_dim=hidden_dimension * 4,
#                           shifted=True, window_size=window_size), # SW-MSA
#             ]))
#         # self.should_reset = True
#         # self.last_hidden = None
#         #
#         # self.compress_in =  nn.Conv2d(6, 3, kernel_size=1, stride=1, padding=0, bias=False),
#     def forward(self, x):
#         # if self.should_reset:
#         #     self.last_hidden = torch.zeros(x.size()).cuda()
#         #     self.last_hidden.copy_(x)
#         #     self.should_reset = False
#         #
#         # x = x + self.last_hidden
#
#
#         x = self.patch_partition(x)
#         for regular_block, shifted_block in self.layers:
#             x = regular_block(x)
#             x = shifted_block(x)
#         x = self.unpatch_partiton(x)
#         return x



class DRN(nn.Module):
    def __init__(self,in_nc, out_nc, nf, nb):
        super().__init__()
        hidden_dim96 = 48
        hidden_dim54 = 54
        layers = (24, 2, 6, 2)
        heads = (3, 6, 12, 24)
        channels = 3
        head_dim = 32
        window_size = 7
        downscaling_factors = (2, 2, 2, 2)
        image_size = 112

        self.stage1 = StageModule(in_channels=channels, hidden_dimension=hidden_dim96, layers=layers[0],
                                  downscaling_factor=downscaling_factors[0], num_heads=heads[0], head_dim=head_dim,
                                  window_size=window_size,image_size=image_size)

        # self.stage2 = StageModule(in_channels=channels, hidden_dimension=hidden_dim96, layers=layers[1],
        #                           downscaling_factor=downscaling_factors[1], num_heads=heads[0], head_dim=head_dim,
        #                           window_size=window_size,image_size=image_size)
        #
        # self.stage3 = StageModule(in_channels=channels, hidden_dimension=hidden_dim96, layers=layers[2],
        #                           downscaling_factor=downscaling_factors[2], num_heads=heads[0], head_dim=head_dim,
        #                           window_size=window_size,image_size=image_size)
        #
        # self.stage4 = StageModule(in_channels=channels, hidden_dimension=hidden_dim96, layers=layers[3],
        #                           downscaling_factor=downscaling_factors[3], num_heads=heads[0], head_dim=head_dim,
        #                           window_size=window_size,image_size=image_size)

        # self.exit_block = nn.Sequential(
        #     nn.BatchNorm2d(3),
        #     nn.Sigmoid()
        # )
        self.upsample = nn.Upsample(scale_factor=2,
                                    mode='bicubic', align_corners=False)

    def forward(self, img):
        img =self.upsample(img)
        x = img
        x = self.stage1(x)
        # x = self.stage2(x)
        # x = self.stage3(x)
        # x = self.stage4(x)
        x = x + img
        return x


class DRN2(nn.Module):
    def __init__(self, opt, conv=common.default_conv):
        super().__init__()
        hidden_dim = 96
        layers = (4, 2, 6, 2)
        heads = (3, 6, 12, 24)
        channels = 3
        head_dim = 32
        window_size = 7
        downscaling_factors = (4, 2, 2, 2)
        image_size = 224
        self.stage1 = StageModule(in_channels=channels, hidden_dimension=hidden_dim, layers=layers[0],
                                  downscaling_factor=downscaling_factors[0], num_heads=heads[0], head_dim=head_dim,
                                  window_size=window_size,image_size=image_size)

        # self.stage2 = StageModule(in_channels=channels, hidden_dimension=hidden_dim, layers=layers[0],
        #                           downscaling_factor=downscaling_factors[0], num_heads=heads[0], head_dim=head_dim,
        #                           window_size=window_size,image_size=image_size)
        #
        # self.stage3 = StageModule(in_channels=channels, hidden_dimension=hidden_dim, layers=layers[0],
        #                           downscaling_factor=downscaling_factors[0], num_heads=heads[0], head_dim=head_dim,
        #                           window_size=window_size,image_size=image_size)
        #
        # self.stage4 = StageModule(in_channels=channels, hidden_dimension=hidden_dim, layers=layers[0],
        #                           downscaling_factor=downscaling_factors[0], num_heads=heads[0], head_dim=head_dim,
        #                           window_size=window_size,image_size=image_size)

        self.exit_block = nn.Sequential(
            nn.BatchNorm2d(3),
            nn.Sigmoid()
        )
        self.upsample = nn.Upsample(scale_factor=4,
                                    mode='bicubic', align_corners=False)
        self.num_steps = 3
    def forward(self, img):
        img =self.upsample(img)
        x = img
        outs = []

        for _ in range(self.num_steps):
            h = self.stage1(x)
            h = torch.add(img, h)
            outs.append(h)

        return outs